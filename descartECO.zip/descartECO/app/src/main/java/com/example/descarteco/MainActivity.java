package com.example.descarteco;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;

import com.example.descarteco.helper.Permissoes;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.os.Message;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentContainer;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.Menu;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        OnMapReadyCallback {

    private GoogleMap mMap;
    private CameraPosition cameraPosition;
    private Geocoder geocoder;

    Double locationLatitude, enderecoLatitude;
    Double locationLongitude, enderecoLongitude;

    LatLng localUsuario;

    ArrayList markerPoints = new ArrayList();

    private String[] permissoes = new String[]{
            Manifest.permission.ACCESS_FINE_LOCATION
    };

    private LocationManager locationManager;
    private LocationListener locationListener; //receber atualizações do usuário


    NavigationView navigationView;

    Menu menu;

    FragmentManager fragmentManager;

    FragmentManager supportFragmentManager;

    private SupportMapFragment mSupportMapFragment;

    Activity activity;

    //FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Validar permissões
        Permissoes.validarPermissoes(permissoes, this, 1);

       /* fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        DrawerLayout drawer = findViewById(R.id.drawer_layout);

        navigationView = findViewById(R.id.nav_view);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);

        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        fragmentManager = getSupportFragmentManager();
        supportFragmentManager = getSupportFragmentManager();

        fragmentManager.beginTransaction().replace(R.id.content_main, new FragmentBlank()).commit();


        mSupportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.content_main);
        if (mSupportMapFragment == null) {
            fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            mSupportMapFragment = SupportMapFragment.newInstance();
            fragmentTransaction.replace(R.id.content_main, mSupportMapFragment).commit();
            mSupportMapFragment.getMapAsync(this);
        } else {
            mSupportMapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    //@Override
    /**public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }*/

    //@Override
    /**public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Você deseja sair?");
                builder.setCancelable(true);
                builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                        System.exit(0);

                    }
                });
                builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();

                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }

        return super.onOptionsItemSelected(item);
    }*/

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            getSupportFragmentManager().beginTransaction().replace(R.id.content_main,
                    new FragmentBlank()).commit();
        } else if (id == R.id.nav_gps) {
            getSupportFragmentManager().beginTransaction().replace(R.id.content_main,
                    new GpsFragment()).commit();
        } else if (id == R.id.nav_recycler) {
            getSupportFragmentManager().beginTransaction().replace(R.id.content_main,
                    new RecycleFragment()).commit();
        } else if (id == R.id.nav_sobre) {
            getSupportFragmentManager().beginTransaction().replace(R.id.content_main,
                    new SobreFragment()).commit();
        } else if (id == R.id.nav_logout) {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setMessage("Você deseja sair?");
            builder.setCancelable(true);
            builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                    System.exit(0);
                }
            });
            builder.setNegativeButton("Não", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            AlertDialog alert = builder.create();
            alert.show();

        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.clear();

        //add um marcador
        //mMap.addMarker(new MarkerOptions().position(localUsuario).title("Meu local").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)));
        mMap.addMarker(new MarkerOptions().position(new LatLng(-6.806045, -35.077605)).title("Magazine Santa Rita"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(-6.808287, -35.075913)).title("Farmácia Rio Tinto"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(-6.805560, -35.075215)).title("Policlínica Rio Tinto"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(-6.809263, -35.076552)).title("Hospital Municipal Francisco Porto"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(-6.8234282, -35.1205767)).title("Secretaria de Saude de Rio Tinto"));
        mMap.addMarker(new MarkerOptions().position(new LatLng(-6.838765, -35.138791)).title("HGM Mamanguape"));
        //.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)) ->MUDAR A COR DO MARCADOR

        //CameraPosition cameraPosition = new CameraPosition.Builder().zoom(15).target(localUsuario).build();
        cameraPosition = new CameraPosition.Builder().zoom(15).target(new LatLng(-6.8083341, -35.0791367)).build();

        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

        //Tipo do mapa
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);


        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) { //informa quando a localização do usuário muda
                Log.d("Localização", "onLocationChanged: " + location.toString());

                locationLatitude = location.getLatitude();
                locationLongitude = location.getLongitude();

                /*
                Geocoding é o processo de transformar um end ou descrição de um local em lat/long
                Reverse Geocoding é o processo de transformar lat/long em um endereço
                 */
                geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());

                try {

                    List<Address> listaEndereco = geocoder.getFromLocation(locationLatitude, locationLongitude, 1);

                    String stringEndereco = "RR. Luís Pedro de Oliveira, Mamanguape, Paraíba";

                    //List<Address> listaEndereco = geocoder.getFromLocationName(stringEndereco,1);

                    if (listaEndereco != null && listaEndereco.size() > 0) {

                        Address endereco = listaEndereco.get(0);

                        Log.d("Local", "onLocationChaged" + endereco.getAddressLine(0));

                        enderecoLatitude = endereco.getLatitude();
                        enderecoLongitude = endereco.getLongitude();

                        // Add marcador em Rio Tinto, Paraiba, and move the camera.
                        localUsuario = new LatLng(enderecoLatitude, enderecoLongitude);

                        //CameraPosition cameraPosition = new CameraPosition.Builder().zoom(15).target(localUsuario).build();
                        cameraPosition = new CameraPosition.Builder().zoom(15).target(new LatLng(-6.8083341, -35.0791367)).build();

                        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

                        //mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(localUsuario, 15));

                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onStatusChanged(String s, int i, Bundle bundle) { //o status do serviço de localiz. muda


            }

            @Override
            public void onProviderEnabled(String s) { //quando o usuário habilida o serviço de localiz.

            }

            @Override
            public void onProviderDisabled(String s) { //quando o usuário desabilita o serviço de localiz.

            }
        };

        //Objeto responsável por gerenciar a localização do usuário
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    0,
                    10,
                    locationListener
            );
        }

        mMap.setMyLocationEnabled(true); //botão de localização e ponto azul no mapa


        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {

                mMap.addMarker(new MarkerOptions()
                        .position(latLng)
                        .title("Local")
                        .snippet("Descrição")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));

                Toast.makeText(MainActivity.this, "Coletar dados para salvar no banco de dados", Toast.LENGTH_SHORT).show();

                if (markerPoints.size() > 1) {
                    markerPoints.clear();
                    //mMap.clear();
                }

                // Adding new item to the ArrayList
                markerPoints.add(latLng);

                // Creating MarkerOptions
                MarkerOptions options = new MarkerOptions();

                // Setting the position of the marker
                options.position(latLng);

                if (markerPoints.size() == 1) {
                    options.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE));
                } else if (markerPoints.size() == 2) {
                    options.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW));
                }

                // Checks, whether start and end locations are captured
                if (markerPoints.size() >= 2) {
                    LatLng origin = (LatLng) markerPoints.get(0);
                    LatLng dest = (LatLng) markerPoints.get(1);

                    // Getting URL to the Google Directions API
                    String url = getDirectionsUrl(origin, dest);

                     DownloadTask downloadTask = new DownloadTask();

                    // Start downloading json data from Google Directions API
                    downloadTask.execute(url);
                }
            }
        });

    }


    private class DownloadTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... url) {

            String data = "";

            try {
                data = downloadUrl(url[0]);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

           ParserTask parserTask = new ParserTask();


            parserTask.execute(result);

        }
    }



    /**
     * A class to parse the Google Places in JSON format
     */
    private class ParserTask extends AsyncTask<String, Integer, List<List<HashMap<String, String>>>> {

        // Parsing the data in non-ui thread
        @Override
        protected List<List<HashMap<String, String>>> doInBackground(String... jsonData) {

            JSONObject jObject;
            List<List<HashMap<String, String>>> routes = null;

            try {
                jObject = new JSONObject(jsonData[0]);
                DirectionsJSONParser parser = new DirectionsJSONParser();

                routes = parser.parse(jObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return routes;
        }

        @Override
        protected void onPostExecute(List<List<HashMap<String, String>>> result) {
            ArrayList points = null;
            PolylineOptions lineOptions = null;
            MarkerOptions markerOptions = new MarkerOptions();

            for (int i = 0; i < result.size(); i++) {
                points = new ArrayList();
                lineOptions = new PolylineOptions();

                List<HashMap<String, String>> path = result.get(i);

                for (int j = 0; j < path.size(); j++) {
                    HashMap<String, String> point = path.get(j);

                    double lat = Double.parseDouble(point.get("lat"));
                    double lng = Double.parseDouble(point.get("lng"));
                    LatLng position = new LatLng(lat, lng);

                    points.add(position);
                }

                lineOptions.addAll(points);
                lineOptions.width(12);
                lineOptions.color(Color.RED);
                lineOptions.geodesic(true);

            }

// Drawing polyline in the Google Map for the i-th route
            try {

                mMap.addPolyline(lineOptions);

            }catch (Exception e){}

        }
    }

    private String getDirectionsUrl(LatLng origin, LatLng dest) {

        // Origin of route
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;

        // Destination of route
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;

        // Sensor enabled
        String sensor = "sensor=false";
        String mode = "mode=driving";
        // Building the parameters to the web service
        String parameters = str_origin + "&" + str_dest + "&" + sensor + "&" + mode;

        // Output format
        String output = "json";

        // Building the url to the web service
        String url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;


        return url;
    }

    /**
     * A method to download json data from url
     */
    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);

            urlConnection = (HttpURLConnection) url.openConnection();

            urlConnection.connect();

            iStream = urlConnection.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));

            StringBuffer sb = new StringBuffer();

            String line = "";
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            data = sb.toString();

            br.close();

        } catch (Exception e) {
            Log.d("Exception", e.toString());
        } finally {
            iStream.close();
            urlConnection.disconnect();
        }
        return data;
    }

}